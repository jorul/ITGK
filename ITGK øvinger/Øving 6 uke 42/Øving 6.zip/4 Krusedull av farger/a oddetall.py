oddetall = []
for i in range(1,20,2):
    oddetall.append(i)
print(oddetall)