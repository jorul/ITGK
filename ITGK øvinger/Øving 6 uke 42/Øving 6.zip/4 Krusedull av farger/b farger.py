brukerfarger = (input('Skriv 10 farger med komma og mellomrom mellom: '))
farger = brukerfarger.split (', ')
print(farger)