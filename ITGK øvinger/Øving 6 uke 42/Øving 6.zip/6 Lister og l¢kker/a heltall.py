number_list = []
for i in range(100):
    number_list.append(i)

print(number_list)