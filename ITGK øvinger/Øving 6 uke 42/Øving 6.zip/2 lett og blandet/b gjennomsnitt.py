def average(i):
    return sum(i)/(len(i))

print(average([1,3,5,7,9,11]))