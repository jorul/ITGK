ukedagene = ['man', 'tir', 'ons', 'tor', 'fre', 'lør', 'søn']
def is_workday(day):
    if 0 <= day <= 4:
        return True
    else:
        return False
