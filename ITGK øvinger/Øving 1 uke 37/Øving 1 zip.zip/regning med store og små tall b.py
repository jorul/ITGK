antall = float(input('Antall ulike 10-toners melodilinjer du har hørt? '))

av_mulig = (antall/(8.25e19))*100

print('Du har hørt', av_mulig, 'prosent av melodier som er mulig')
