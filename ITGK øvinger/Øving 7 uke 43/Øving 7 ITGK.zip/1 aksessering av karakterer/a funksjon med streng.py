def skriv_streng(strengen):
    for ch in strengen:
        print(ch)

skriv_streng('Discworld')