def not_indexerror(streng):
    return len(streng)-1

print(not_indexerror('The Way of Kings'))