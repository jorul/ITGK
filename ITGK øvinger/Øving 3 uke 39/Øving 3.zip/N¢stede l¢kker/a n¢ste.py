import random

Stud = ['Jorunn', 'Jørgen', 'Jostein']
Emne = ['ITGK', 'Exphil', 'Diskmat', 'Matte 1']
verb = ['elsker', 'hater', 'liker', 'misliker', 'digger', 'liker ikke', 'synes ikke noe om', 'har ikke tid til', 'vil heller dø enn å ha']
for x in range(0,3):
    for y in range(0,4):
        print(f'{random.choice(Stud)} {random.choice(verb)} {random.choice(Emne)}', end=' og ')
    print()