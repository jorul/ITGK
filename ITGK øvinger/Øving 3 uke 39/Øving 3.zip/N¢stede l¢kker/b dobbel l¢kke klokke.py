for t in range(0,24):
    for m in range (0,60):
        print(f'{t}:{m}')