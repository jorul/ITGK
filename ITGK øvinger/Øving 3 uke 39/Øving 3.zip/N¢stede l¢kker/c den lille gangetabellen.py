for x in range(1,11):
    for y in range(1,11):
        print(str(x*y).ljust(3), end = ' ')
    print()