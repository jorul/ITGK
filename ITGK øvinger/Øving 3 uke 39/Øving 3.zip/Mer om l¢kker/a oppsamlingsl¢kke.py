summen = 0
for i in range(1, 8):
    tall = int(input('Skriv inn et heltall: ')) 
    summen += tall          # summen = summen + i
print("Summen av tallene ble:", summen)
