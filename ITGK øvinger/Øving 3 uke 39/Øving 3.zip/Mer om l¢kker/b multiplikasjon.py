prod = 1
i = 0
while prod <= 1000:
    i += 1
    prod *= i
print(prod)